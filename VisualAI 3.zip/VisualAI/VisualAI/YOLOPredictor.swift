import CoreML
import CoreVideo
import Foundation
import ImageIO
import Vision

struct YOLOPrediction: Identifiable, Sendable {
    let id: UUID
    let label: String
    let confidence: Float
    let boundingBox: CGRect

    init(
        id: UUID = UUID(),
        label: String,
        confidence: Float,
        boundingBox: CGRect
    ) {
        self.id = id
        self.label = label
        self.confidence = confidence
        self.boundingBox = boundingBox
    }
}

/// Adaptateur pour les modèles YOLO Core ML dont Vision retourne
/// des VNRecognizedObjectObservation.
///
/// Pour un export YOLO qui retourne des MLMultiArray bruts, il faut
/// implémenter le décodage des tenseurs et le NMS séparément.
final class YOLOPredictor: CoreMLPredictor, @unchecked Sendable {

    typealias Prediction = YOLOPrediction

    private let visionModel: VNCoreMLModel
    private let minimumConfidence: VNConfidence
    private let cropAndScaleOption: VNImageCropAndScaleOption
    private let orientation: CGImagePropertyOrientation

    init(
        model: MLModel,
        minimumConfidence: VNConfidence = 0.5,
        cropAndScaleOption: VNImageCropAndScaleOption = .scaleFill,
        orientation: CGImagePropertyOrientation = .up
    ) throws {
        self.visionModel = try VNCoreMLModel(for: model)
        self.minimumConfidence = minimumConfidence
        self.cropAndScaleOption = cropAndScaleOption
        self.orientation = orientation
    }

    func predict(
        pixelBuffer: CVPixelBuffer
    ) async throws -> [YOLOPrediction] {

        try await withCheckedThrowingContinuation { continuation in
            let request = VNCoreMLRequest(model: visionModel) {
                [minimumConfidence] request, error in

                if let error {
                    continuation.resume(throwing: error)
                    return
                }

                guard let observations =
                    request.results as? [VNRecognizedObjectObservation]
                else {
                    continuation.resume(
                        throwing: YOLOPredictorError.unsupportedOutput
                    )
                    return
                }

                let predictions = observations.compactMap {
                    observation -> YOLOPrediction? in

                    guard let label = observation.labels.first,
                          label.confidence >= minimumConfidence
                    else {
                        return nil
                    }

                    return YOLOPrediction(
                        label: label.identifier,
                        confidence: label.confidence,
                        boundingBox: observation.boundingBox
                    )
                }

                continuation.resume(returning: predictions)
            }

            request.imageCropAndScaleOption = cropAndScaleOption

            let handler = VNImageRequestHandler(
                cvPixelBuffer: pixelBuffer,
                orientation: orientation,
                options: [:]
            )

            do {
                try handler.perform([request])
            } catch {
                continuation.resume(throwing: error)
            }
        }
    }
}

enum YOLOPredictorError: Error {
    case unsupportedOutput
}
