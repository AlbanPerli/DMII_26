import AVFoundation
import CoreImage
import SwiftUI
import Combine

@MainActor
final class CameraML<Predictor: CoreMLPredictor>: NSObject, ObservableObject {

    @Published private(set) var image: CGImage?
    @Published private(set) var predictions: [Predictor.Prediction] = []
    @Published private(set) var isRunning = false

    let session = AVCaptureSession()

    private let predictor: Predictor
    private let ciContext = CIContext()

    private let captureDelegate: CameraFrameDelegate

    private var isConfigured = false
    private var inferenceTask: Task<Void, Never>?

    init(predictor: Predictor) {
        self.predictor = predictor
        self.captureDelegate = CameraFrameDelegate()
        super.init()

        captureDelegate.onFrame = { [weak self] pixelBuffer in
            guard let self else { return }

            Task { @MainActor in
                self.receive(pixelBuffer: pixelBuffer)
            }
        }
    }

    deinit {
        inferenceTask?.cancel()
    }

    func start() async {
        guard await requestCameraAuthorization() else {
            return
        }

        if !isConfigured {
            do {
                try configureSession()
                isConfigured = true
            } catch {
                print("CameraML configuration error:", error)
                return
            }
        }

        guard !session.isRunning else {
            return
        }

        let session = self.session

        Task.detached(priority: .userInitiated) {
            session.startRunning()
        }

        isRunning = true
    }

    func stop() {
        inferenceTask?.cancel()
        inferenceTask = nil

        let session = self.session

        Task.detached(priority: .userInitiated) {
            if session.isRunning {
                session.stopRunning()
            }
        }

        isRunning = false
    }

    private func requestCameraAuthorization() async -> Bool {
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            return true

        case .notDetermined:
            return await AVCaptureDevice.requestAccess(for: .video)

        default:
            return false
        }
    }

    private func configureSession() throws {
        session.beginConfiguration()
        defer { session.commitConfiguration() }

        session.sessionPreset = .high

        guard let device = AVCaptureDevice.default(
            .builtInWideAngleCamera,
            for: .video,
            position: .back
        ) else {
            throw CameraError.cameraUnavailable
        }

        let input = try AVCaptureDeviceInput(device: device)

        guard session.canAddInput(input) else {
            throw CameraError.cannotAddInput
        }

        session.addInput(input)

        let output = AVCaptureVideoDataOutput()

        output.alwaysDiscardsLateVideoFrames = true
        output.videoSettings = [
            kCVPixelBufferPixelFormatTypeKey as String:
                kCVPixelFormatType_32BGRA
        ]

        output.setSampleBufferDelegate(
            captureDelegate,
            queue: captureDelegate.queue
        )

        guard session.canAddOutput(output) else {
            throw CameraError.cannotAddOutput
        }

        session.addOutput(output)

        if let connection = output.connection(with: .video),
           connection.isVideoRotationAngleSupported(90) {
            connection.videoRotationAngle = 90
        }

        captureDelegate.videoOutput = output
    }

    private func receive(pixelBuffer: CVPixelBuffer) {
        publishImage(from: pixelBuffer)

        // Une seule inférence à la fois : si le modèle travaille encore,
        // la nouvelle frame est ignorée.
        guard inferenceTask == nil else {
            return
        }

        let predictor = self.predictor

        inferenceTask = Task { [weak self] in
            guard let self else { return }

            do {
                let result = try await predictor.predict(
                    pixelBuffer: pixelBuffer
                )

                guard !Task.isCancelled else {
                    self.inferenceTask = nil
                    return
                }

                self.predictions = result
            } catch is CancellationError {
                // Arrêt normal.
            } catch {
                print("CameraML prediction error:", error)
            }

            self.inferenceTask = nil
        }
    }

    private func publishImage(from pixelBuffer: CVPixelBuffer) {
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)

        guard let cgImage = ciContext.createCGImage(
            ciImage,
            from: ciImage.extent
        ) else {
            return
        }

        image = cgImage
    }
}

extension CameraML {
    enum CameraError: Error {
        case cameraUnavailable
        case cannotAddInput
        case cannotAddOutput
    }
}

/// Le delegate AVFoundation est séparé de l'ObservableObject afin que le
/// callback vidéo reste hors du MainActor.
private final class CameraFrameDelegate:
    NSObject,
    AVCaptureVideoDataOutputSampleBufferDelegate,
    @unchecked Sendable {

    let queue = DispatchQueue(
        label: "CameraML.video",
        qos: .userInitiated
    )

    var onFrame: (@Sendable (CVPixelBuffer) -> Void)?

    // Conserve fortement la sortie vidéo pendant toute la session.
    var videoOutput: AVCaptureVideoDataOutput?

    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let pixelBuffer =
            CMSampleBufferGetImageBuffer(sampleBuffer)
        else {
            return
        }

        onFrame?(pixelBuffer)
    }
}
