import CoreVideo

protocol CoreMLPredictor: Sendable {
    associatedtype Prediction: Sendable

    func predict(pixelBuffer: CVPixelBuffer) async throws -> [Prediction]
}
