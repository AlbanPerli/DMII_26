//
//  VisualAIApp.swift
//  VisualAI
//
//  Created by Al on 18/09/2026.
//

import SwiftUI

@main
struct VisualAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
