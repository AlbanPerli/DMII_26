//
//  CameraView.swift
//  VisualAI
//
//  Created by Al on 18/09/2026.
//

import SwiftUI

struct CameraView: View {

    @ObservedObject var camera: CameraML<YOLOPredictor>

    var body: some View {
        VStack {
            if let image = camera.image {
                Image(
                    image,
                    scale: 1,
                    label: Text("Camera")
                )
                .resizable()
                .scaledToFit()
            }
            Text(
                "\(camera.predictions.count) objets"
            )
            ForEach(camera.predictions) { prediction in
                HStack {
                    Text(prediction.label)
                    Spacer()
                    Text(
                        "\(Int(prediction.confidence * 100)) %"
                    )
                }
            }
        }
        .task {
            await camera.start()
        }
        .onDisappear {
            camera.stop()
        }
    }
}
