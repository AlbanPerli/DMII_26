//
//  ContentView.swift
//  VisualAI
//
//  Created by Al on 18/09/2026.
//

import SwiftUI
import CoreML

struct ContentView: View {

    @StateObject private var camera: CameraML<YOLOPredictor>

    init() {
        do {
            let model = try YOLOv3TinyInt8LUT(
                configuration: MLModelConfiguration()
            )
            let predictor = try YOLOPredictor(
                model: model.model,
                minimumConfidence: 0.5
            )
            _camera = StateObject(
                wrappedValue: CameraML(
                    predictor: predictor
                )
            )
        } catch {
            fatalError(
                "Impossible de charger YOLO: \(error)"
            )
        }
    }

    var body: some View {
        CameraView(camera: camera)
    }

}
#Preview {
    ContentView()
}
