import Vapor

let app = try await Application.make()

app.http.server.configuration.hostname = "0.0.0.0"

app.http.server.configuration.port = 8080


var idList: [String] = []

app.webSocket("ws") { _, ws in
    print("Client connecté")
    ws.onText { ws, message in
        //print(message)
        
        if let messageObj = Message.fromJSON(json: message){
            
            let emetteur = messageObj.emetteur
            let receiver = messageObj.receiver
            let content = messageObj.message
            
            idList.append(emetteur)
            idList = Array(Set(idList))
            print("Id list : \(idList)")
            
            let responseMessage = Message(emetteur: "Serveur", message: content, receiver: emetteur)
            
            print("\(emetteur) m'a écrit")
            print("\(content)")
            
            let echo = responseMessage.toString()
            ws.send(echo)
        }
    }
    ws.onClose.whenComplete { _ in
        print("Client déconnecté")

    }

}

try await app.execute()
