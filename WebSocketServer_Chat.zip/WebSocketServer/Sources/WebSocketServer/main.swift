import Vapor

let app = try await Application.make()

app.webSocket("ws") { _, ws in
    print("🟢 Client connecté")

    ws.onText { ws, message in
        print("📩 \(message)")
        ws.send("Réponse du serveur : \(message)")
    }

    ws.onClose.whenComplete { _ in
        print("🔴 Client déconnecté")
    }
}

try await app.execute()
