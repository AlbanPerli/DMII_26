import Vapor

let app = try await Application.make()

app.http.server.configuration.hostname = "0.0.0.0"

app.http.server.configuration.port = 8080
var dictId_WS: [String: WebSocket] = [:]

app.webSocket("ws") { _, ws in
    print("Client connecté")
    ws.onText { ws, message in
        //print(message)
        
        if let messageObj = Message.fromJSON(json: message){
            let emetteur = messageObj.emetteur
            let receiver = messageObj.receiver
            let content = messageObj.message
            
            print("\(emetteur) m'a écrit")
            print("\(content)")
            print("Receiver: \(receiver)")
            
            // Mise à jour de la liste
            dictId_WS.updateValue(ws, forKey: emetteur)
            
            // Ecrire à SERVER avec le message ID_LIST
            if content == "ID_LIST" && receiver == "SERVER" {
                let userList:[String] = dictId_WS.keys.map(\.self)
                var userListString: String = userList.joined(separator: "#")
                for (key,value) in dictId_WS {
                    dictId_WS[key]?.send(Message(emetteur: "SERVER", message: userListString, receiver: key).toString())
                }
            }else{

                if dictId_WS.keys.contains(receiver) == false {
                    ws.send(Message(emetteur: "Server", message: "UnKnow user", receiver: emetteur).toString())
                }else{
                    dictId_WS[receiver]?.send(message)
                }
            }
            
            
            
            
        }
    }
    ws.onClose.whenComplete { _ in
        print("Client déconnecté")

    }

}

try await app.execute()
