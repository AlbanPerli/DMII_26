# WebSocketServer

Serveur WebSocket minimal en Swift avec Vapor.

## Lancer

```bash
swift run
```

Le WebSocket est disponible sur :

`ws://127.0.0.1:8080/ws`
