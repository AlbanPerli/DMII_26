// swift-tools-version: 6.0

import PackageDescription

let package = Package(
    name: "WebSocketServer",
    platforms: [
        .macOS(.v13)
    ],
    dependencies: [
        .package(
            url: "https://github.com/vapor/vapor.git",
            from: "4.0.0"
        )
    ],
    targets: [
        .executableTarget(
            name: "WebSocketServer",
            dependencies: [
                .product(name: "Vapor", package: "vapor")
            ]
        )
    ]
)
