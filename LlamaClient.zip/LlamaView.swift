//
//  LlamaView.swift
//  FirstApp
//
//  Created by Al on 17/09/2026.
//

import SwiftUI

struct LlamaView: View {

    @StateObject private var llama = LlamaClient(
        baseURL: "http://192.168.4.16:8080"
    )

    @State private var prompt = ""

    var body: some View {

        VStack(spacing: 20) {

            TextField(
                "Pose une question...",
                text: $prompt
            )
            .textFieldStyle(.roundedBorder)

            Button("Envoyer") {

                let currentPrompt = prompt
                prompt = ""

                Task {
                    await llama.send(prompt: currentPrompt)
                }
            }
            .disabled(llama.isLoading)

            if llama.isLoading {
                ProgressView("Llama réfléchit...")
            }

            ScrollView {
                Text(llama.response)
                    .frame(
                        maxWidth: .infinity,
                        alignment: .leading
                    )
            }

            if let error = llama.errorMessage {
                Text(error)
                    .foregroundStyle(.red)
            }
        }
        .padding()
    }
}
