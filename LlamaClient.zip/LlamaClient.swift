//
//  LlamaClient.swift
//  FirstApp
//
//  Created by Al on 17/09/2026.
//

import Foundation
import Combine

@MainActor
final class LlamaClient: ObservableObject {

    @Published var response: String = ""
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let baseURL: URL
    private let apiKey: String?

    init(
        baseURL: String = "http://127.0.0.1:8080",
        apiKey: String? = nil
    ) {
        guard let url = URL(string: baseURL) else {
            fatalError("URL du serveur invalide")
        }

        self.baseURL = url
        self.apiKey = apiKey
    }

    // MARK: - Structures OpenAI

    struct ChatMessage: Codable {
        let role: String
        let content: String
    }

    struct ChatRequest: Codable {
        let model: String
        let messages: [ChatMessage]
        let temperature: Double
        let max_tokens: Int
    }

    struct ChatResponse: Codable {

        struct Choice: Codable {

            struct Message: Codable {
                let role: String
                let content: String
            }

            let index: Int
            let message: Message
            let finish_reason: String?
        }

        let choices: [Choice]
    }

    // MARK: - Envoi du prompt

    func send(
        prompt: String,
        systemPrompt: String = "Tu es un assistant utile.",
        model: String = "llama",
        temperature: Double = 0.7,
        maxTokens: Int = 1024
    ) async {

        guard !prompt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return
        }

        isLoading = true
        errorMessage = nil

        defer {
            isLoading = false
        }

        do {

            let url = baseURL.appendingPathComponent("v1/chat/completions")

            var request = URLRequest(url: url)

            request.httpMethod = "POST"

            request.setValue(
                "application/json",
                forHTTPHeaderField: "Content-Type"
            )

            // Clé API si nécessaire
            if let apiKey {
                request.setValue(
                    "Bearer \(apiKey)",
                    forHTTPHeaderField: "Authorization"
                )
            }

            let body = ChatRequest(
                model: model,
                messages: [
                    ChatMessage(
                        role: "system",
                        content: systemPrompt
                    ),
                    ChatMessage(
                        role: "user",
                        content: prompt
                    )
                ],
                temperature: temperature,
                max_tokens: maxTokens
            )

            request.httpBody = try JSONEncoder().encode(body)

            let (data, urlResponse) = try await URLSession.shared.data(
                for: request
            )

            guard let httpResponse = urlResponse as? HTTPURLResponse else {
                throw LlamaError.invalidResponse
            }

            guard (200...299).contains(httpResponse.statusCode) else {

                let message = String(
                    data: data,
                    encoding: .utf8
                ) ?? "Erreur inconnue"

                throw LlamaError.server(
                    statusCode: httpResponse.statusCode,
                    message: message
                )
            }

            let result = try JSONDecoder().decode(
                ChatResponse.self,
                from: data
            )

            guard let content = result.choices.first?.message.content else {
                throw LlamaError.noContent
            }

            response = content

        } catch {

            errorMessage = error.localizedDescription
            print("Erreur LlamaClient :", error)
        }
    }
}


// MARK: - Erreurs

enum LlamaError: LocalizedError {

    case invalidResponse
    case noContent
    case server(statusCode: Int, message: String)

    var errorDescription: String? {

        switch self {

        case .invalidResponse:
            return "Réponse HTTP invalide."

        case .noContent:
            return "Le serveur n'a retourné aucune réponse."

        case .server(let statusCode, let message):
            return "Erreur serveur \(statusCode) : \(message)"
        }
    }
}
