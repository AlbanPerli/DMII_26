import Vapor

let app = try await Application.make()

// Configuration du serveur
app.http.server.configuration.hostname = "0.0.0.0"
app.http.server.configuration.port = 8080

// Association : ID utilisateur -> WebSocket
var dictId_WS: [String: WebSocket] = [:]

app.webSocket("ws") { _, ws in

    print("Client connecté")

    // MARK: - Réception d'un message

    ws.onText { ws, message in

        guard let messageObj = Message.fromJSON(json: message) else {
            print("Message JSON invalide")
            return
        }

        let emetteur = messageObj.emetteur
        let receiver = messageObj.receiver
        let content = messageObj.message

        print("\(emetteur) m'a écrit")
        print("Message : \(content)")
        print("Receiver : \(receiver)")

        // Enregistrement / mise à jour du client
        dictId_WS[emetteur] = ws

        print("Clients connectés : \(dictId_WS.keys)")

        // MARK: - Demande de la liste des utilisateurs

        if content == "ID_LIST" && receiver == "SERVER" {

            let userList = Array(dictId_WS.keys)
            let userListString = userList.joined(separator: "#")

            print("Liste des utilisateurs : \(userListString)")

            // Envoi de la liste à tous les clients
            for (id, socket) in dictId_WS {

                let response = Message(
                    emetteur: "SERVER",
                    message: userListString,
                    receiver: id
                )

                socket.send(response.toString())
            }

            return
        }

        // MARK: - Transmission du message
        guard let receiverWS = dictId_WS[receiver] else {
            print("Utilisateur \(receiver) inconnu")
            let response = Message(
                emetteur: "SERVER",
                message: "Unknown user",
                receiver: emetteur
            )
            ws.send(response.toString())
            return
        }
        // Transmission au destinataire
        receiverWS.send(message)
    }


    // MARK: - Déconnexion

    ws.onClose.whenComplete { _ in

        print("Client déconnecté")

        // Recherche de l'identifiant associé à cette WebSocket
        if let id = dictId_WS.first(where: { $0.value === ws })?.key {

            // Suppression ID + WebSocket
            dictId_WS.removeValue(forKey: id)

            let userList = Array(dictId_WS.keys)
            let userListString = userList.joined(separator: "#")

            print("Utilisateur \(id) supprimé")
            print("Clients restants : \(dictId_WS.keys)")
            
            for (id, socket) in dictId_WS {

                let response = Message(
                    emetteur: "SERVER",
                    message: userListString,
                    receiver: id
                )

                socket.send(response.toString())
            }

        } else {

            print("WebSocket déconnectée sans identifiant associé")
        }
    }
}


// MARK: - Démarrage du serveur

try await app.execute()
