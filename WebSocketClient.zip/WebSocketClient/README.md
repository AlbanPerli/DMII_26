# WebSocketClient

Client WebSocket Swift minimal utilisant `URLSessionWebSocketTask`.

## Prérequis

Lancer d'abord WebSocketServer.

## Lancer

```bash
swift run
```

Par défaut, le client se connecte à :

`ws://127.0.0.1:8080/ws`
