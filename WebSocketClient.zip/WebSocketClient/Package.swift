// swift-tools-version: 6.0

import PackageDescription

let package = Package(
    name: "WebSocketClient",
    platforms: [
        .macOS(.v13)
    ],
    targets: [
        .executableTarget(
            name: "WebSocketClient"
        )
    ]
)
