//
//  ButtonView.swift
//  Projet1
//
//  Created by Al on 15/09/2026.
//

import SwiftUI

struct ButtonView: View {
    
    var action: (Int) -> Void
    
    var body: some View {
        VStack{
            Button("Btn 1", action: {
                action(1)
            })
            Button("Btn 2", action: {
                action(2)
            })
            Button("Btn 3", action: {
                action(3)
            })
        }
    }
}

#Preview {
    ButtonView { _ in
        print("Hello")
    }
    
}
