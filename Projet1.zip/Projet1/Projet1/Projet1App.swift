//
//  Projet1App.swift
//  Projet1
//
//  Created by Al on 14/09/2026.
//

import SwiftUI

@main
struct Projet1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView(currentImageContent: ImageContent(imageUrl: "URL", description:"MaDesc"))
        }
    }
}
