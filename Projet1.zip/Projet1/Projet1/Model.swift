//
//  Model.swift
//  Projet1
//
//  Created by Al on 15/09/2026.
//

class ImageInfoModel {
    
    var imageInfoList: [ImageContent] = [
        ImageContent(imageUrl: "https://upload.wikimedia.org/wikipedia/commons/6/66/Ludwig_Wittgenstein_4-5%28cropped%29.jpg?utm_source=fr.wikipedia.org&utm_campaign=imageinfo&utm_content=original", description: "Ma desc 1"),
        ImageContent(imageUrl: "", description: "Ma desc 2"),
        ImageContent(imageUrl: "", description: "Ma desc 3")
    ]
    
}
