//
//  OnLineImageDesc.swift
//  Projet1
//
//  Created by Al on 15/09/2026.
//


import SwiftUI

struct ImageContent {
    var imageUrl: String
    var description: String
}


struct OnlineImageDesc: View {
    
    var content: ImageContent
    
    var body: some View {
        VStack{
            AsyncImage(url: URL(string: content.imageUrl)) { image in
                image
                    .resizable()
                    .scaledToFit()
            } placeholder: {
                ProgressView()
            }
            Text(content.description)
        }
    }
}

#Preview {
    OnlineImageDesc(content: ImageContent(imageUrl: "Mon url", description: "Mon descriptif"))
}
