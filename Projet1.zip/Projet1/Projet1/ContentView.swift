//
//  ContentView.swift
//  Projet1
//
//  Created by Al on 14/09/2026.
//

import SwiftUI

struct ContentView: View {
    
    var imageInfoModel = ImageInfoModel()
    
    @State var currentImageContent: ImageContent
    
    var body: some View {
        HStack {
            Spacer()
            ButtonView { btnId in
                print("Action Clicked \(btnId)")
                let normalizedIdx = btnId-1
                if normalizedIdx < imageInfoModel.imageInfoList.count {
                    currentImageContent = imageInfoModel.imageInfoList[normalizedIdx]
                }else{
                    print("BtnId is out of range")
                }
                
            }
            Spacer()
            Rectangle()
                .frame(width: 1)
            Spacer()
            OnlineImageDesc(content: currentImageContent)
            Spacer()
        }
        
    }
    
}


#Preview {
    ContentView(currentImageContent: ImageContent(imageUrl: "Url", description: "Desc"))
}
































