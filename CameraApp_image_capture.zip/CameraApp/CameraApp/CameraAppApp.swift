//
//  CameraAppApp.swift
//  CameraApp
//
//  Created by Al on 15/09/2026.
//

import SwiftUI

@main
struct CameraAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
