import SwiftUI
import AVFoundation
import Combine


final class CameraManager: NSObject, ObservableObject, AVCaptureVideoDataOutputSampleBufferDelegate {

    let session = AVCaptureSession()

    func start() {
        session.beginConfiguration()
        session.sessionPreset = .high

        guard let camera = AVCaptureDevice.default(
            .builtInWideAngleCamera,
            for: .video,
            position: .unspecified
        ) else {
            print("Aucune caméra trouvée")
            session.commitConfiguration()
            return
        }

        do {
            let input = try AVCaptureDeviceInput(device: camera)

            if session.canAddInput(input) {
                session.addInput(input)
            }
        } catch {
            print("Erreur caméra :", error)
        }

        // Récupération des images
        let output = AVCaptureVideoDataOutput()

        output.setSampleBufferDelegate(
            self,
            queue: DispatchQueue(label: "camera.frames")
        )

        if session.canAddOutput(output) {
            session.addOutput(output)
        }

        session.commitConfiguration()

        DispatchQueue.global(qos: .userInitiated).async {
            self.session.startRunning()
        }
    }

    func stop() {
        DispatchQueue.global(qos: .userInitiated).async {
            self.session.stopRunning()
        }
    }

    // Appelé pour chaque image reçue
    func captureOutput(
        _ output: AVCaptureOutput,
        didOutput sampleBuffer: CMSampleBuffer,
        from connection: AVCaptureConnection
    ) {
        guard let image = CMSampleBufferGetImageBuffer(sampleBuffer) else {
            return
        }

        // Ton image est ici (CVPixelBuffer)
        print("Image reçue :", image)
        
    }
}
