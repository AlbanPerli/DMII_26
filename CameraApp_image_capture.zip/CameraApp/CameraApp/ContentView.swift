//
//  ContentView.swift
//  CameraApp
//
//  Created by Al on 15/09/2026.
//

import SwiftUI

struct ContentView: View {

    @StateObject private var camera = CameraManager()

    var body: some View {

        Button("Start") {
            camera.start()
        }
        Button("Stop") {
            camera.stop()
        }
        CameraPreview(session: camera.session)
            .frame(minWidth: 640, minHeight: 480)
            .onAppear {
                camera.start()
            }
            .onDisappear {
                camera.stop()
            }
    }

}

#Preview {
    ContentView()
}
