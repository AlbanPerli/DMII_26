//
//  ConnexionStateView.swift
//  WS_client
//
//  Created by Al on 16/09/2026.
//

import SwiftUI

struct ConnexionStateView: View {
    
    enum ButtonAction{
        case connect
        case disconnect
    }
    
    @Binding var isConnected: Bool
    var action: (ButtonAction)->Void
    
    var body: some View {
        if isConnected {
            Button("Disconnect"){
                action(.disconnect)
            }
            Text("Connecté")
        }else{
            Button("Connect"){
                action(.connect)
            }
            Text("Deconnecté")
        }
    }
    
}

#Preview {
    /*
    ConnexionStateView(isConnected: <#Binding<Bool>#>){_ in
        
    }
    */
}
