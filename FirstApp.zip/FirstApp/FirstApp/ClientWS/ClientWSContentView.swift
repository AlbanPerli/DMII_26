//
//  ContentView.swift
//  WS_client
//
//  Created by Al on 16/09/2026.
//

import SwiftUI

struct ClientWSContentView: View {
    
    @StateObject var client:ClientObservable = ClientObservable(urlString: "ws://127.0.0.1:8080/ws")
    
    @State var messageToSend:String = ""
    
    var body: some View {
        VStack {
            HStack{
                ConnexionStateView(isConnected: $client.isConnected ) { expectedAction in
                    switch expectedAction {
                        case .connect:
                            client.connect()
                        case .disconnect:
                            client.disconnect()
                    }
                }
            }
            
            HStack{
                TextField("Message", text: $messageToSend)
                Button("Send") {
                    let message = Message(emetteur: "Alban", message: messageToSend, receiver: "Serveur")
                    let messageStr = message.toString()
                    print(messageStr)
                    client.send(message: messageStr)
                }
            }
            Text(client.receivedMessage.emetteur)
            Text(client.receivedMessage.message)
            
            Button("Simule reception") {
                client.receive()
            }
            
        }
        .padding()
    }
}

#Preview {
    ClientWSContentView()
}
