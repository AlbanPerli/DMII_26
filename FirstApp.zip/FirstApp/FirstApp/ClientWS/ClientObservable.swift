//
//  clientObservable.swift
//  WS_client
//
//  Created by Al on 16/09/2026.
//

import Foundation
import Combine

class ClientObservable:ObservableObject {
    
    @Published var receivedMessage:Message = Message(emetteur: "", message: "", receiver: "")
    
    @Published var isConnected:Bool = false
    
    var url:URL
    var socket:URLSessionWebSocketTask

    init(urlString:String) {
        self.url = URL(string: urlString)!
        self.socket = URLSession.shared.webSocketTask(with: url)
    }
    
    func connect(){
        print("Demande de connexion")
        isConnected = true
        self.socket = URLSession.shared.webSocketTask(with: self.url)
        self.receive()
        self.socket.resume()
    }
    
    
    func disconnect(){
        print("Demande de deconnexion")
        isConnected = false
        self.socket.cancel()
    }
    
    func send(message:String){
        print("Message à envoyer: \(message)")
        socket.send(.string(message)) { error in
            if let error {
                print("❌ Envoi : \(error)")
            } else {
                print("📤 Bonjour serveur")
            }
        }

    }
    
    func receive(){
        
        socket.receive { result in
            switch result {
            case .success(.string(let text)):
                print("\(text)")
                if let message = Message.fromJSON(json: text){
                    DispatchQueue.main.async{
                        self.receivedMessage = message
                    }
                }
                
            case .success(.data(let data)):
                print("\(data.count) octets reçus")

            case .success:
                print("Sans contenu ni format")

            case .failure(let error):
                print("❌ Réception : \(error)")
            }
            self.receive()
        }
        
    }
    
}
