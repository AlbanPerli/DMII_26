//
//  ContentView.swift
//  FirstApp
//
//  Created by Al on 17/09/2026.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView{
            ClientWSContentView()
                .tabItem {
                    Label("Accueil", systemImage: "house.fill")
                }
            
            LlamaView()
                .tabItem {
                    Label("Accueil", systemImage: "house.fill")
                }
            
            Text("Hello")
                .tabItem {
                    Label("Accueil", systemImage: "house.fill")
                }
        }
    }
}

#Preview {
    ContentView()
}
