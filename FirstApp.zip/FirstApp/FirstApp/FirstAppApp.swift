//
//  FirstAppApp.swift
//  FirstApp
//
//  Created by Al on 17/09/2026.
//

import SwiftUI

@main
struct FirstAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
