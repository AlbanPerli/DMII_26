//
//  GridView.swift
//  FirstApp
//
//  Created by Al on 17/09/2026.
//
import SwiftUI

struct GridView: View {
    let rows: Int
    let columns: Int

    var body: some View {
        LazyVGrid(
            columns: Array(
                repeating: GridItem(.flexible(), spacing: 8),
                count: columns
            ),
            spacing: 8
        ) {
            ForEach(0..<(rows * columns), id: \.self) { index in
                RoundedRectangle(cornerRadius: 8)
                    .fill(.blue.opacity(0.2))
                    .aspectRatio(1, contentMode: .fit)
                    .overlay {
                        Text("\(index)")
                    }
            }
        }
        .padding()
    }

}
